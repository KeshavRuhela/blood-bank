<?php 
require "../database/main.php";
require "../headLink/all_link.php";
session_start();

$userid = $_SESSION['userid'];
    $name = $_POST['pname'];
    $blood = $_POST['pblood'];
    $email = $_POST['pemail'];
    $mobile = $_POST['pmobile'];
    $add = $_POST['padd'];
    $city = $_POST['pcity'];
    $zip = $_POST['pzip'];
    $state = $_POST['pstate'];
    // $name = $_POST['pcity'];

    $sql_query = "INSERT INTO arrise_request (name, blood, email, mobile, state, address, userid) VALUES ('$name', '$blood','$email',$mobile,'$state','$add $city $zip $state', $userid)";
    $result = mysqli_query($conn, $sql_query) or die(mysqli_error($conn));
    require "../database/main.php";

    if ($result) {
        $insert = true;
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>sucess!</strong>your request send.
                    <a id="count">a</a><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    ';
    }
?>
<script type='text/javascript'>
    var count = document.getElementById('count')
    const delay = ms => new Promise(res => setTimeout(res, ms));
    const change = async () => {
        let i =1;
    while (i!=3){
        count.innerHTML = 3-i;

        await delay(1000);
        i++;
    }
    location.replace("../index.php");

//   console.log("Waited 5s");
    };
    change();
    </script>

    