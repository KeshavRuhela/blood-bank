<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div style="background:#c6cabe; height:40px; padding:8px; width:100%; text-align:center;"><u><b>Keshav Ruhela</b>© 2023-2024 Internship assignment</u></div>
</body>
</html>