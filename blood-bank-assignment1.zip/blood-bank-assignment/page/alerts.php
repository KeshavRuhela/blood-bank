<?php
    session_start();
    // echo "$_SESSION[regDone]";
    if (isset($_SESSION['regDone']))
        echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>registered!</strong> You have to login on our site.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    if (isset($_SESSION['userLogin']))
      if($_SESSION['userLogin']){
        if (isset($_SESSION['usertype'])){
      if($_SESSION['usertype'] == 'h')
        echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>LogedIn!</strong> you are logedIn as Hospital.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      }
      }
    if (isset($_SESSION['userLogin']))
      if($_SESSION['userLogin']){
      if (isset($_SESSION['usertype'])){
      if($_SESSION['usertype'] == 'r')
        echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>LogedIn!</strong> you are logedIn as Requester.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
      }
    }
    // if (isset($_SESSION['usertype']))
    //   if($_SESSION['usertype'] == 'h')
    //     echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
    //     <strong>LogedIn!</strong> you are logedIn as Hospital.
    //     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    //   </div>';
    // if (isset($_SESSION['usertype']))
    //   if($_SESSION['usertype'] == 'r')
    //     echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
    //     <strong>LogedIn!</strong> you are logedIn as Requester.
    //     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    //   </div>';
    if (isset($_SESSION['userLogin']))
      if($_SESSION['userLogin']== false)
        echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>not LogedIn!</strong>pass or email is wrong.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    if (isset($_SESSION['emailExist'])){
        echo '<div style="margin:auto;" class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong>Alert!</strong> email already exist.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
        echo '<div style="margin:auto;" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Alert!</strong> you have to login on our site.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    

    // session_destroy();
    
?>