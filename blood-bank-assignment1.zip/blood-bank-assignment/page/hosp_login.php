<?php
require "../database/main.php";
include "../headLink/all_link.php";

    if ($_SERVER['REQUEST_METHOD']== "POST"){
        $email = $_POST['hemail'];
        $pass = $_POST['hpass'];
        
        $sql_query = "select * from hosp_login";
        $result = mysqli_query($conn, $sql_query) or die(mysqli_error($conn));
        echo var_dump($result);
        $log = false;
        while ($row = mysqli_fetch_assoc($result)){
            if ($row['email'] == $email) {
                if ($row['password'] == $pass){
                    $userid =$row['uniq_id'];
                    $log = true;
                    echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>logedIn!</strong>you are logedIn as hospital.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';
                }
                break;
            }
        }
        if ($log){
        session_destroy();

        session_start();
        $_SESSION['userLogin'] = true;
        $_SESSION['regEmail'] = $email;
        $_SESSION['usertype'] = 'h';
        $_SESSION['userid'] = $userid;
        }else{
        $_SESSION['userLogin'] = false;
        }

        header("Location:../index.php");
        exit();
        // session_destroy();
        
    }
    
    if (isset($_SESSION['userLogin'])){
        if($_SESSION['userLogin'] == false){
            header("Location:login.html");
            exit();
        }
        else{
            header("Location:../index.php");
            exit();
        }
    }
    else {
        header("Location:login.html");
            exit();
    }
    
