<?php
session_start();
if (isset($_SESSION['userLogin'])){
    if ($_SESSION['userLogin']){

        if ($_SESSION['usertype'] == 'r'){
            header("Location:ariserequest.html");
            exit();
        }else {
        echo "<h1>you are login as hospital u can't send request";
        }
    }
    else{
        header("Location:login.php");
            exit();
    }

}
else{
    header("Location:request.html");
    exit();
}


?>