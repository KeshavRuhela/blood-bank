<nav class="navbar navbar-expand-lg navbar-light customNav">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Blood Bank</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="http://localhost/blood-bank-assignment">Home</a>
                </li>
                <li class="nav-item">
                    <div class="dropdown">
                        <a class="nav-link active dropdown-toggle" id="register" data-bs-toggle="dropdown" aria-expanded="false" aria-current="page" href="#">Register</a>
                        <ul class="dropdown-menu" aria-labelledby="register">
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#hospitalReg">As Hospital</a></li>
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#reqReg">As Requester</a></li>
                        </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <div class="dropdown">
                        <a class="nav-link active  dropdown-toggle" id="login" data-bs-toggle="dropdown" aria-expanded="false" aria-current="page" href="">Login</a>
                        <ul class="dropdown-menu" aria-labelledby="login">
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#hospitalLogin">As Hospital</a></li>
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#reqLogin">As Requester</a></li>
                        </ul>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Features</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page/request.php">Request</a>
                </li>
            </ul>
            <span class="navbar-text">
                Try to saves life
            </span>
        </div>
    </div>
</nav>