<?php 
    require 'database/main.php';
    require 'headLink/all_link.php';

    echo"<a style='font-size:18px; font-weight:600; position:fixed; top:50%;right:5%;'>we can also use datatable for better experience</a>";
    $sql_query = 'select * from arrise_request';
    $result = mysqli_query($conn, $sql_query) or die(mysqli_error($conn));
    $insert = true;
    while ($row = mysqli_fetch_assoc($result)){
        echo "<div class='card m-5 custom_css' style='width:40%;'>
        <div class='card-header'>
          $row[name]
        </div>
        <div class='card-body' style='background:#ff8e8e !important;'>
          <h5 class='card-title'>$row[blood] user Id : $row[userid]</h5>
          <p class='card-text'>$row[email] </p>
          <p class='card-text'>$row[mobile] </p>
          <p class='card-text'>$row[address]</p>
          <a href='#' class='btn btn-primary'>Go somewhere</a>
        </div>
      </div>";
        }

?>