<?php
require "main.php";
include "../headLink/all_link.php";


$name = $_POST['rname'];
$blood = $_POST['rblood'];
$email = $_POST['remail'];
$add = $_POST['radd'];
$pass = $_POST['rpass'];
$city = $_POST['rcity'];
$zip = $_POST['rzip'];
$state = $_POST['rstate'];
// $mobile = $_POST['rmobile'];




$sql_query = "select * from rec_login";
$result = mysqli_query($conn, $sql_query) or die(mysqli_error($conn));
$insert = true;
while ($row = mysqli_fetch_assoc($result))
    if ($row['email'] == $email) {
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>warrning!</strong>This email alread exists.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        $insert = false;
        break;
    }




if ($insert) {
    $query = "insert into rec_login(name, blood, email, password, mobile, address, state) values('$name','$blood','$email','$pass',' ','$add $city $zip $state', '$state')";
    // echo $query;
    $result = mysqli_query($conn, $query);
    if ($result)
        echo "execute";
    else {
        header("Location:../index.php");
        exit();
    }
    require "close.php";
} else {
    session_start();
    $_SESSION['emailExist'] = true;
    $_SESSION['regEmail'] = $email;
    $_SESSION['usertype'] = 'r';
    header("Location:../index.php");
    exit();
}

session_start();
$_SESSION['regDone'] = true;
$_SESSION['regEmail'] = $email;
$_SESSION['usertype'] = 'r';
header("Location:../index.php");
exit();
