<?php 
    require "main.php";
    include "../headLink/all_link.php";


    $name = $_POST['hname'];
    // $blood = $_POST['hblood'];
    $email = $_POST['hemail'];
    $add = $_POST['hadd'];
    $pass = $_POST['hpass'];
    $city = $_POST['hcity'];
    $zip = $_POST['hzip'];
    $state = $_POST['hstate'];
    $mobile = $_POST['hmobile'];
    echo $mobile;

    // echo "$name $blood $email $add $pass $city $zip";
    


    $sql_query = "select * from hosp_login";
    $result = mysqli_query($conn, $sql_query) or die (mysqli_error ($conn));
    echo var_dump($result);
    $insert = true;
    while ($row = mysqli_fetch_assoc($result))
        if ($row['email'] == $email){
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>warrning!</strong>This email alread exists.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
            $insert = false; 
            break;
        }
        
    
    
    
    if ($insert){
        $query = "insert into hosp_login(name, email, password, mobile, address,state) values('$name','$email','$pass','$mobile','$add $city $zip $state','$state')";
        echo $query;
        $result = mysqli_query($conn, $query);
        if ($result)
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>sucess!</strong>now login.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>'; 
        else {
            header("Location:../index.php");
            exit();
        }
        require "close.php";
    
    }
    else {
        session_start();
        $_SESSION['emailExist'] = true;
        $_SESSION['regEmail'] = $email;
        $_SERVER['usertype'] = 'r';
        // session_abort();
        header("Location:../index.php");
        exit();
        
    }

    session_start();
    $_SESSION['regDone'] = true;
    $_SESSION['regEmail'] = $email;
    $_SESSIONE['usertype'] = 'r';
    // session_abort();
    header("Location:../index.php");
    exit();