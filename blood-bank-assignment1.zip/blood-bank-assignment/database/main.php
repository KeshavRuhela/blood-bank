<?php 
    $server = "localhost";
    $user = "kes";
    $dbname = "epiz_33429135_blood";
    $pass = "12345";

    $conn = mysqli_connect($server,$user,$pass,$dbname);
if (!$conn)
    echo "connection intrupt try after some time !";
?>