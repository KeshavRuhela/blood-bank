<?php 
require "headLink/all_link.php";
require "page/alerts.php";
// session_start();
// echo var_dump($_SESSION['emailExist']);
require "file/navbar.php";
require "modal/hospitallogin.php";
require "modal/requesterlogin.php";

if(isset($_SESSION['userLogin']))
    echo "<a href='logout.php'><button type='button' class='btn btn-danger m-3'>Log Out</button></a>";
if(isset($_SESSION['userLogin']))
if($_SESSION['usertype'] == 'h')
    echo '<a href="request.php"><button type="button m-3" class="btn btn-secondary">View Request</button></a>';

echo '<img src="image/R.jpg" width="100%" class="img-fluid" alt="...">';

require "page/footer.php";

?>


