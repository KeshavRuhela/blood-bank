<!--login Modal -->
<div class="modal fade" id="reqLogin" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="reqLoginLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="reqLoginLabel">Requester Login</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form class="row g-3" method="POST" action="./page/req_login.php">
                        <div class="col-md-11">
                            <label for="remail" class="form-label">Email</label>
                            <input type="email" class="form-control" name="remail" id="remail">
                        </div>
                        <div class="col-md-11">
                            <label for="rpass" class="form-label">Password</label>
                            <input type="password" class="form-control" value="" name="rpass" id="rpass">
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">SignUp</button>
                        </div>
                    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<!--registration Modal -->
<div class="modal fade" id="reqReg" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="reqLoginLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="reqLoginLabel">Requester Registration</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form class="row g-3" method="post" action="../../blood-bank-assignment/database/rasr.php">
                        <div class="col-md-9">
                            <label for="rname" class="form-label">Name</label>
                            <input type="text" class="form-control" name="rname" id="rname">
                        </div>
                        <div class="col-md-3">
                            <label for="rblood" class="form-label">Blood Group</label>
                            <input type="text" class="form-control" name="rblood" id="rblood">
                        </div>
                        <div class="col-md-6">
                            <label for="remail" class="form-label">Email</label>
                            <input type="email" class="form-control" name="remail" id="remail">
                        </div>
                        <div class="col-md-6">
                            <label for="rpass" class="form-label">Password</label>
                            <input type="password" class="form-control" value="" name="rpass" id="rpass">
                        </div>
                        <div class="col-12">
                            <label for="radd" class="form-label">Address</label>
                            <input type="text" class="form-control" name="radd" id="radd" placeholder="1234 Main St">
                        </div>
                        <div class="col-md-6">
                            <label for="rcity" class="form-label">City</label>
                            <input type="text" name="rcity" class="form-control" id="rcity">
                        </div>
                        <div class="col-md-4">
                            <label for="rstate" class="form-label">State</label>
                            <select id="rstate" name="rstate" class="form-select">
                                <option selected value="AN">Andaman and Nicobar Islands</option>
                                <option value="AP">Andhra Pradesh</option>
                                <option value="AR">Arunachal Pradesh</option>
                                <option value="AS">Assam</option>
                                <option value="BR">Bihar</option>
                                <option value="CH">Chandigarh</option>
                                <option value="CT">Chhattisgarh</option>
                                <option value="DN">Dadra and Nagar Haveli</option>
                                <option value="DD">Daman and Diu</option>
                                <option value="DL">Delhi</option>
                                <option value="GA">Goa</option>
                                <option value="GJ">Gujarat</option>
                                <option value="HR">Haryana</option>
                                <option value="HP">Himachal Pradesh</option>
                                <option value="JK">Jammu and Kashmir</option>
                                <option value="JH">Jharkhand</option>
                                <option value="KA">Karnataka</option>
                                <option value="KL">Kerala</option>
                                <option value="LA">Ladakh</option>
                                <option value="LD">Lakshadweep</option>
                                <option value="MP">Madhya Pradesh</option>
                                <option value="MH">Maharashtra</option>
                                <option value="MN">Manipur</option>
                                <option value="ML">Meghalaya</option>
                                <option value="MZ">Mizoram</option>
                                <option value="NL">Nagaland</option>
                                <option value="OR">Odisha</option>
                                <option value="PY">Puducherry</option>
                                <option value="PB">Punjab</option>
                                <option value="RJ">Rajasthan</option>
                                <option value="SK">Sikkim</option>
                                <option value="TN">Tamil Nadu</option>
                                <option value="TG">Telangana</option>
                                <option value="TR">Tripura</option>
                                <option value="UP">Uttar Pradesh</option>
                                <option value="UT">Uttarakhand</option>
                                <option value="WB">West Bengal</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="rzip" class="form-label">Zip</label>
                            <input type="text" name="rzip" class="form-control" id="rzip">
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="rcheck">
                                <label class="form-check-label" for="rcheck">
                                    trems & condition
                                </label>
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">SignUp</button>
                        </div>
                    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Submit</button> -->
      </div>
    </div>
  </div>
</div>