<!-- Login Modal -->
<div class="modal fade" id="hospitalLogin" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="hospitalLoginLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="hospitalLoginLabel">Hospital Login</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="row g-3" method="post" action="http://localhost/blood-bank-assignment/page/hosp_login.php">
          <div class="col-md-11">
            <label for="hemail" class="form-label">Email</label>
            <input type="email" name="hemail" class="form-control" id="hemail">
          </div>
          <div class="col-md-11">
            <label for="hpass" class="form-label">Password</label>
            <input type="password" name="hpass" class="form-control" id="hpass">
          </div>
          <div class="col-12">
            <button type="submit" class="btn btn-primary">SignUp</button>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<!-- Registration Modal -->
<div class="modal fade" id="hospitalReg" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="hospitalLoginLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="hospitalLoginLabel">Hospital Registration</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="row g-3" method="POST" action="../../blood-bank-assignment/database/rash.php">
          <div class="col-md-12">
            <label for="hname" class="form-label">Hospital Name</label>
            <input type="text" name="hname" class="form-control" id="hname">
          </div>
          <div class="col-md-6">
            <label for="hemail" class="form-label">Email</label>
            <input type="email" name="hemail" class="form-control" id="hemail">
          </div>
          <div class="col-md-6">
            <label for="hpass" class="form-label">Password</label>
            <input type="password" name="hpass" class="form-control" id="hpass">
          </div>
          <div class="col-md-10">
            <label for="hmobile" class="form-label">Mobile</label>
            <input type="number" name="hmobile" class="form-control" id="hmobile">
          </div>
          <div class="col-12">
            <label for="hadd" class="form-label">Address</label>
            <input type="text" name="hadd" class="form-control" id="hadd" placeholder="1234 Main St">
          </div>
          <div class="col-md-6">
            <label for="hcity" class="form-label">City</label>
            <input type="text" name="hcity" class="form-control" id="hcity">
          </div>
          <div class="col-md-4">
            <label for="hstate" class="form-label">State</label>
            <select id="hstate" name="hstate" class="form-select" required>
              <option selected value="AN">Andaman and Nicobar Islands</option>
              <option value="AP">Andhra Pradesh</option>
              <option value="AR">Arunachal Pradesh</option>
              <option value="AS">Assam</option>
              <option value="BR">Bihar</option>
              <option value="CH">Chandigarh</option>
              <option value="CT">Chhattisgarh</option>
              <option value="DN">Dadra and Nagar Haveli</option>
              <option value="DD">Daman and Diu</option>
              <option value="DL">Delhi</option>
              <option value="GA">Goa</option>
              <option value="GJ">Gujarat</option>
              <option value="HR">Haryana</option>
              <option value="HP">Himachal Pradesh</option>
              <option value="JK">Jammu and Kashmir</option>
              <option value="JH">Jharkhand</option>
              <option value="KA">Karnataka</option>
              <option value="KL">Kerala</option>
              <option value="LA">Ladakh</option>
              <option value="LD">Lakshadweep</option>
              <option value="MP">Madhya Pradesh</option>
              <option value="MH">Maharashtra</option>
              <option value="MN">Manipur</option>
              <option value="ML">Meghalaya</option>
              <option value="MZ">Mizoram</option>
              <option value="NL">Nagaland</option>
              <option value="OR">Odisha</option>
              <option value="PY">Puducherry</option>
              <option value="PB">Punjab</option>
              <option value="RJ">Rajasthan</option>
              <option value="SK">Sikkim</option>
              <option value="TN">Tamil Nadu</option>
              <option value="TG">Telangana</option>
              <option value="TR">Tripura</option>
              <option value="UP">Uttar Pradesh</option>
              <option value="UT">Uttarakhand</option>
              <option value="WB">West Bengal</option>
            </select>
          </div>
          <div class="col-md-2">
            <label for="hzip" class="form-label">Zip</label>
            <input type="text" name="hzip" class="form-control" id="hzip">
          </div>
          <div class="col-12">
            <div class="form-check">
              <input class="form-check-input" name="hcheck" type="checkbox" id="hcheck">
              <label class="form-check-label" for="hcheck">
                trems & condition
              </label>
            </div>
          </div>
          <div class="col-12">
            <button type="submit" class="btn btn-primary">SignUp</button>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Submit</button> -->
      </div>
    </div>
  </div>
</div>